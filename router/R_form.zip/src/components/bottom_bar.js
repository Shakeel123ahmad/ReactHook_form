
const Feter = () => {
    return (
        <div className="flex justify-around bg-blue-300 py-2">
            <div className="">
                <p className="">
                    <b> Name : </b>  Shakee
                    <b> sapid : </b>  12345
                </p>
            </div>
            <div className="contact">
                <p>
                    <b> email : </b> shakeesialvi6@gmail.com
                    <b> phone_number : </b> 123456789
                </p>
            </div>

            <div className="address">
                <p>
                    <b> homeAdress : </b> lahore
                    <b>fax_number : </b>098765
                </p>
            </div>
        </div>

    );
}

export default Feter;