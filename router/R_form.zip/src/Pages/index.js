import Home from "./Home";
import About from "./About";
import Todos from "./Todos";
import Form from "./Form";
import Rform from "./Rform";
export {Home,About,Todos,Form,Rform};