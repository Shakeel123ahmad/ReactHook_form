import Navigator from "../../components/NavBar";
const About = () => {
    return (  
        <>
        <Navigator/>
        <h1 className="text-center my-20">About Page</h1>
        </>
    );
}
export default About;