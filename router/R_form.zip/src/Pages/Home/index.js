import Navigator from "../../components/NavBar";
const Home = () => {
    return ( 
<>

        <Navigator/>
        <h1 className="text-center my-20">Home Page</h1>
</>
     );
}
export default Home ;

